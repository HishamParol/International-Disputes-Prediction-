readme.txt

1. Open Jupiter Course Work.Rproj

2. Open JupiterCourseWork.R

3. Tick 'Source on Save' and run

4. Output can be found in project: Results.csv; graphs are saved as pdf as well as text files with DT output.

5. Regression test are run independently by using 'Source on Save' on Jregression.R

 